import csv
import numpy as np
import matplotlib.pyplot as plt
import jieba
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from datetime import datetime
from sklearn.metrics import accuracy_score, recall_score, f1_score

def get_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class TextVectorizer(object):
    def __init__(self):
        self.vectorizer = None
        self.label = None

    def _get_vocabulary(self, vector):
        return set([word for sublist in vector for word in sublist])

    def _create_bow_vector(self, words, vocab):
        bow_vector = [0] * len(vocab)
        for word in words:
            if word in vocab:
                index = list(vocab).index(word)
                bow_vector[index] += 1
        return bow_vector

    def read_file(self, file_path, skip_header=True):
        print(f'{get_timestamp()} read initial file: {file_path}')
        with open(file_path, 'r', encoding='utf-8') as f:
            if skip_header:
                f.readline()
            reader = csv.reader(f)
            return [row for row in reader]

    def split_data(self, data):
        label = [row[0] for row in data]
        review = [row[1] for row in data]
        return np.array(label), np.array(review)

    def load_stop_words(self, file_path):
        """
        读取停用词文件。
        参数:
            file_path (str): 停用词文件的路径。
        返回:
            list: 包含停用词的列表。
        """
        print(f'{get_timestamp()} 读取停用词文件: {file_path}')
        # 从csv文件中读取停用词
        stopwords = []
        with open(file_path, 'r', encoding='utf-8') as f:
            # 跳过第一行表头
            f.readline()
            reader = csv.reader(f)
            for row in reader:
                stopwords.append(row[0])
        return stopwords

    def save_vector_data(self, label, vector, file_path_save):
        with open(file_path_save, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            # 表头：label, x0, x1, ...
            writer.writerow(['label'] + ['x' + str(i) for i in range(len(vector[0]))])
            for i in range(len(label)):
                writer.writerow([label[i]] + vector[i])  # 写入label和特征向量

    def text_to_vector(self, data, stopwords=None, use_jieba=True):
        print(f'{get_timestamp()} 开始数据集汉字的向量化处理')

        # 逐个汉字进行分词
        vector = []
        for review in data:
            words = []
            for word in review:
                if word not in stopwords:
                    words.append(word)
            vector.append(words)

        # 使用jieba分词
        if use_jieba:
            print(f'{get_timestamp()} 使用jieba库进行分词...')
            # jieba.enable_paddle()
            # vector = [list(jieba.cut(''.join(words), use_paddle=True)) for words in vector]
            try:
                # 尝试启用PaddlePaddle加速（如果安装了paddlepaddle-tiny）
                import jieba
                jieba.enable_paddle()  # 启用Paddle加速
                vector = [list(jieba.cut(''.join(words))) for words in vector]  # 移除use_paddle参数
            except:
                # 如果Paddle不可用，回退到普通模式
                vector = [list(jieba.cut(''.join(words))) for words in vector]

        # 词袋模型的向量化
        vocab = self._get_vocabulary(vector)
        vectorized_data = [self._create_bow_vector(words, vocab) for words in vector]

        self.vectorizer = vectorized_data
        return vectorized_data


class MLModel(object):
    def __init__(self):
        self.clf = None
        self.accuracy = None
        #
        self.recall = None
        self.f1 = None

    def train_and_evaluate(self, X_train, X_test, y_train, y_test, model_name='Decision Tree'):
        """训练和评估单个模型"""
        model_map = {
            'Decision Tree': DecisionTreeClassifier(),
            'KNN': KNeighborsClassifier(),
            'Naive Bayes': GaussianNB(),
            'LogisticRegression': LogisticRegression(max_iter=1000),
            'RandomForestClassifier': RandomForestClassifier()
        }

        if model_name not in model_map:
            raise ValueError(f"未知模型名称: {model_name}")

        self.clf = model_map[model_name]
        self.clf.fit(X_train, y_train)
        y_pred = self.clf.predict(X_test)

        self.accuracy = accuracy_score(y_test, y_pred)
        self.recall = recall_score(y_test, y_pred, average='weighted')
        self.f1 = f1_score(y_test, y_pred, average='weighted')

        return self.accuracy, self.recall, self.f1


class TextProcessingPipeline(object):
    def __init__(self):
        self.text_vectorizer = TextVectorizer()
        self.ml_model = MLModel()
        self.label = None
        self.data = None

    def process_data(self, file_path_read, file_path_save, file_path_saved='vectorized_data.csv', use_jieba=True):
        print(f'{get_timestamp()} 读取原始数据集文件: {file_path_read}')
        # 读取原始数据
        listdata = self.text_vectorizer.read_file(file_path_read)
        # 分割标签和文本
        label, review = self.text_vectorizer.split_data(listdata)
        # 加载停用词
        stopwords = self.text_vectorizer.load_stop_words('stop_words.csv')
        # 文本向量化
        vector = self.text_vectorizer.text_to_vector(review, stopwords, use_jieba)
        # 保存向量化数据
        self.text_vectorizer.save_vector_data(label, vector, file_path_saved)
        # 读取处理后的数据到内存
        self.label, self.data = self.read_processed_data(file_path_saved)  # 确保返回并赋值
        return self.label, self.data  # 显式返回

    def read_processed_data(self, file_path, skip_header=True):
        print(f'{get_timestamp()} 读取向量化数据集文件: {file_path}')
        label = []
        data = []
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            if skip_header:
                next(reader)  # 跳过表头
            for row in reader:
                if not row:  # 跳过空行
                    continue
                try:
                    label.append(int(row[0]))
                    data.append([float(x) for x in row[1:]])
                except (ValueError, IndexError) as e:
                    print(f"警告：忽略异常行 {row}（错误: {e}）")
        return np.array(label), np.array(data)  # 转换为numpy数组

    # def train_and_evaluate_models(self, use_jieba=True):
    #     X_train, X_test, y_train, y_test = train_test_split(self.data, self.label, test_size=0.2)
    #     model_names = ['Decision Tree', 'KNN', 'Naive Bayes', 'SVM', 'LogisticRegression', 'RandomForestClassifier']
    #     accuracies = []
    #
    #     # for model_name in model_names:
    #     #     self.ml_model.train_and_evaluate(X_train, X_test, y_train, y_test, model_name)
    #     #     accuracies.append(self.ml_model.accuracy)
    #     #
    #     # if use_jieba:
    #     #     print('使用jieba分词的情况:')
    #     # else:
    #     #     print('不使用jieba分词的情况:')
    #     # print(model_names)
    #     # print(accuracies)
    #     #
    #     # return model_names, accuracies
    #
    #     # 修改为存储多个指标
    #     results = {
    #         'model_names': model_names,
    #         'accuracies': [],
    #         'recalls': [],
    #         'f1_scores': []
    #     }
    #
    #     for model_name in model_names:
    #         accuracy, recall, f1 = self.ml_model.train_and_evaluate(
    #             X_train, X_test, y_train, y_test, model_name)
    #         results['accuracies'].append(accuracy)
    #         results['recalls'].append(recall)
    #         results['f1_scores'].append(f1)
    #
    #     if use_jieba:
    #         print('\n使用jieba分词的情况:')
    #     else:
    #         print('\n不使用jieba分词的情况:')
    #
    #     # 打印更详细的评估结果
    #     print(f"{'模型名称':<20}{'准确率':<10}{'召回率':<10}{'F1分数':<10}")
    #     for name, acc, rec, f1 in zip(results['model_names'],
    #                                   results['accuracies'],
    #                                   results['recalls'],
    #                                   results['f1_scores']):
    #         print(f"{name:<20}{acc:<10.4f}{rec:<10.4f}{f1:<10.4f}")
    #
    #     return results
    def train_and_evaluate_models(self, use_jieba=True):
        """训练和评估多个模型"""
        if self.data is None or self.label is None:
            raise ValueError("请先调用process_data()方法加载数据")

        X_train, X_test, y_train, y_test = train_test_split(
            self.data, self.label, test_size=0.2, random_state=42)

        model_names = ['Decision Tree', 'KNN', 'Naive Bayes',
                       'LogisticRegression', 'RandomForestClassifier']

        results = {
            'model_names': model_names,
            'accuracies': [],
            'recalls': [],
            'f1_scores': []
        }

        for model_name in model_names:
            try:
                accuracy, recall, f1 = self.ml_model.train_and_evaluate(
                    X_train, X_test, y_train, y_test, model_name)
                results['accuracies'].append(accuracy)
                results['recalls'].append(recall)
                results['f1_scores'].append(f1)
            except Exception as e:
                print(f"训练{model_name}时出错: {str(e)}")
                # 添加默认值避免程序中断
                results['accuracies'].append(0)
                results['recalls'].append(0)
                results['f1_scores'].append(0)

        # 打印结果表格
        print(f"\n{'模型名称':<20}{'准确率':<10}{'召回率':<10}{'F1分数':<10}")
        for name, acc, rec, f1 in zip(results['model_names'],
                                      results['accuracies'],
                                      results['recalls'],
                                      results['f1_scores']):
            print(f"{name:<20}{acc:<10.4f}{rec:<10.4f}{f1:<10.4f}")

        return results


def plot_metrics_comparison(model_names, results_jieba, results_no_jieba):
    metrics = ['accuracies', 'recalls', 'f1_scores']
    metric_names = ['Accuracy', 'Recall', 'F1 Score']

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    for idx, (metric, name) in enumerate(zip(metrics, metric_names)):
        ax = axes[idx]
        x = np.arange(len(model_names))
        width = 0.35

        # 绘制第一组柱状图
        jieba_bars = ax.bar(x - width / 2, results_jieba[metric], width, label='with jieba')

        # 绘制第二组柱状图
        no_jieba_bars = ax.bar(x + width / 2, results_no_jieba[metric], width, label='without jieba')

        # 添加数据标签
        for i, v in enumerate(results_jieba[metric]):
            ax.text(x[i] - width / 2, v, f"{v:.2f}", ha='center', va='bottom')
        for i, v in enumerate(results_no_jieba[metric]):
            ax.text(x[i] + width / 2, v, f"{v:.2f}", ha='center', va='bottom')

        ax.set_xticks(x)
        ax.set_xticklabels(model_names, rotation=45)
        ax.set_ylabel(name)
        ax.set_title(f'{name} Comparison')
        ax.legend()

    plt.tight_layout()
    plt.show()


# if __name__ == "__main__":
#     # 实例化处理流程对象并执行
#     pipeline = TextProcessingPipeline()
#
#     # 测试使用jieba进行分词的结果
#     pipeline.process_data('中文外卖评论数据集.csv', 'vectorized_data_nojieba.csv', use_jieba=True)
#     model_names, accuracies_jieba = pipeline.train_and_evaluate_models(use_jieba=True)
#
#     # 测试不使用jieba而只进行字分词结果
#     pipeline.process_data('中文外卖评论数据集.csv', 'vectorized_data_nojieba.csv', use_jieba=False)
#     model_names, accuracies_no_jieba = pipeline.train_and_evaluate_models(use_jieba=False)
#
#     # 绘制柱状图
#     plot_accuracy_comparison(model_names, accuracies_jieba, accuracies_no_jieba)


# if __name__ == "__main__":
#     pipeline = TextProcessingPipeline()
#
#     # 处理数据并确保数据加载成功
#     label_jieba, data_jieba = pipeline.process_data(
#         '中文外卖评论数据集.csv',
#         'vectorized_data_jieba.csv',
#         use_jieba=True
#     )
#
#     # 训练和评估模型
#     model_names, accuracies_jieba = pipeline.train_and_evaluate_models(use_jieba=True)
#
#     # 同样的流程处理不使用jieba的情况
#     label_no_jieba, data_no_jieba = pipeline.process_data(
#         '中文外卖评论数据集.csv',
#         'vectorized_data_nojieba.csv',
#         use_jieba=False
#     )
#     model_names, accuracies_no_jieba = pipeline.train_and_evaluate_models(use_jieba=False)
#
#     # 绘制对比图
#     plot_accuracy_comparison(model_names, accuracies_jieba, accuracies_no_jieba)


if __name__ == "__main__":
    pipeline = TextProcessingPipeline()

    # 处理数据并训练模型（使用jieba）
    pipeline.process_data('中文外卖评论数据集.csv', 'vectorized_data_jieba.csv', use_jieba=True)
    results_jieba = pipeline.train_and_evaluate_models(use_jieba=True)

    # 处理数据并训练模型（不使用jieba）
    pipeline.process_data('中文外卖评论数据集.csv', 'vectorized_data_nojieba.csv', use_jieba=False)
    results_no_jieba = pipeline.train_and_evaluate_models(use_jieba=False)

    # 绘制对比图
    plot_metrics_comparison(results_jieba['model_names'], results_jieba, results_no_jieba)