import csv


def check_csv_file(file_path):
    """
    检查CSV文件的完整性，返回空行或列数不足的行号
    参数:
        file_path (str): CSV文件路径
    返回:
        list: 存在问题的行号列表（从1开始计数）
    """
    error_lines = []

    with open(file_path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)  # 读取表头（第一行）
        expected_columns = len(header)

        for line_num, row in enumerate(reader, start=2):  # 从第2行开始检查
            if not row:  # 空行
                error_lines.append((line_num, "空行"))
            elif len(row) < expected_columns:  # 列数不足
                error_lines.append((line_num, f"列数不足（应有{expected_columns}列，实际{len(row)}列）"))

    return error_lines


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("用法: python check_csv.py <CSV文件路径>")
        sys.exit(1)

    file_path = sys.argv[1]
    errors = check_csv_file(file_path)

    if not errors:
        print(f"文件 '{file_path}' 检查通过，无空行或列数不足的问题。")
    else:
        print(f"文件 '{file_path}' 发现问题（行号从1开始计数）:")
        for line_num, reason in errors:
            print(f"  第 {line_num} 行: {reason}")